<?php

include 'Core/includecore.php';
include 'Extensions/includeextensions.php';
include 'Status/includestatus.php';
include 'Users/includeusers.php';
include 'Gates/includegates.php';
include 'Tools/includetools.php';

?>