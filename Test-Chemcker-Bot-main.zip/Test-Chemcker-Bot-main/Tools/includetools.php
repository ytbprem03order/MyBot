<?php

include 'ip.php';
include 'id.php';
include 'bin.php';
include 'reload.php';
include 'horrorscope.php';

?>